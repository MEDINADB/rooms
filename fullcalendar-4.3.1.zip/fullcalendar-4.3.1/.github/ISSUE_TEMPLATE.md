### Bug Reports
You MUST post a recreation or else your issue will be CLOSED without explanation.
Instructions: https://fullcalendar.io/reporting-bugs

### Feature Requests
Search the issue tracker for an existing ticket before creating a new one.
Instructions: https://fullcalendar.io/requesting-features

### React/Vue/Angular/etc
If your bug is specific to one of these frameworks, use the corresponding tracker.
List: https://github.com/fullcalendar

(Please erase the above text and begin typing. Thanks!)
